﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividadeRevisao
{
    public partial class FrmRevisao : Form
    {
        public FrmRevisao()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valor1 = float.Parse(txtValor1.Text);
            float valor2 = float.Parse(txtValor2.Text);
            float valor3 = float.Parse(txtValor3.Text);
            float resultado1;
            float resultado2;
            float resultado3;

            resultado1 = (valor1 * 10 / 100);
            resultado2 = (valor2 * 10 / 100);
            resultado3 = (valor3 * 10 / 100);

            lblValor1.Text = "Resultado é " + resultado1;
            lblValor2.Text = "Resultado é " + resultado2;
            lblValor3.Text = "Resultado é " + resultado3;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValor1.Clear();
            txtValor2.Clear();
            txtValor3.Clear();
            lblValor1.Text = "-";
            lblValor2.Text = "-";
            lblValor3.Text = "-";

        }
    }
}
