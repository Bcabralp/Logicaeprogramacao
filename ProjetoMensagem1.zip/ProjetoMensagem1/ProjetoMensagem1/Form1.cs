﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoMensagem1
{
    public partial class Mensagem : Form
    {
        public Mensagem()
        {
            InitializeComponent();
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            
            
        }

        private void Mensagem_Load(object sender, EventArgs e)
        {
            
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Apertou Botao Mostrar");
                
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Apertou Botao Limpar");
        }
    }
}
