﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float soma;

            soma = Num1 + Num3;

            lblRSoma.Text = "Resultado da soma é " + soma;


        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float media;

            media = (Num1 + Num2 + Num3) / 3;

            lblRMedia.Text = "A média dos valores é " + media;

                  }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;

            total = Num1 + Num2 + Num3;
            porcNum1 = Num1 / total;
            porcNum2 = Num2 / total;
            porcNum3 = Num3 / total;

            lblPorcent.Text = "Num1 é " + porcNum1 + "% - " + "Num2 é " + porcNum2 + "% -" + "Num3 é " + porcNum3 + "% -"; 
        }
    }
}
