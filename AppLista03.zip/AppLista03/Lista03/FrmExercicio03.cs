﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio03 : Form
    {
        public FrmExercicio03()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float refe = float.Parse(txtQuilo.Text);
            float prat = float.Parse(txtPrato.Text);
            float mutiplicacao;

            mutiplicacao = refe * prat;

            lblPagar.Text = "O valor a pagar pela refeição é " + mutiplicacao;

        }
    }
}
