﻿namespace Lista03
{
    partial class FrmExercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblQuilo = new System.Windows.Forms.Label();
            this.lblPrato = new System.Windows.Forms.Label();
            this.txtQuilo = new System.Windows.Forms.TextBox();
            this.txtPrato = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblPagar = new System.Windows.Forms.Label();
            this.Exr3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblQuilo
            // 
            this.lblQuilo.AutoSize = true;
            this.lblQuilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuilo.Location = new System.Drawing.Point(77, 68);
            this.lblQuilo.Name = "lblQuilo";
            this.lblQuilo.Size = new System.Drawing.Size(236, 24);
            this.lblQuilo.TabIndex = 0;
            this.lblQuilo.Text = "Preço do quilo da refeição:";
            // 
            // lblPrato
            // 
            this.lblPrato.AutoSize = true;
            this.lblPrato.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrato.Location = new System.Drawing.Point(77, 178);
            this.lblPrato.Name = "lblPrato";
            this.lblPrato.Size = new System.Drawing.Size(221, 24);
            this.lblPrato.TabIndex = 1;
            this.lblPrato.Text = "Quilo do prato do cliente:";
            // 
            // txtQuilo
            // 
            this.txtQuilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuilo.Location = new System.Drawing.Point(81, 114);
            this.txtQuilo.Name = "txtQuilo";
            this.txtQuilo.Size = new System.Drawing.Size(306, 26);
            this.txtQuilo.TabIndex = 2;
            // 
            // txtPrato
            // 
            this.txtPrato.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrato.Location = new System.Drawing.Point(81, 220);
            this.txtPrato.Name = "txtPrato";
            this.txtPrato.Size = new System.Drawing.Size(306, 26);
            this.txtPrato.TabIndex = 3;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.Pink;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(436, 152);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(131, 63);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblPagar
            // 
            this.lblPagar.AutoSize = true;
            this.lblPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPagar.Location = new System.Drawing.Point(197, 296);
            this.lblPagar.Name = "lblPagar";
            this.lblPagar.Size = new System.Drawing.Size(133, 20);
            this.lblPagar.TabIndex = 5;
            this.lblPagar.Text = "O valor a pagar é:";
            // 
            // Exr3
            // 
            this.Exr3.AutoSize = true;
            this.Exr3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exr3.Location = new System.Drawing.Point(30, 21);
            this.Exr3.Name = "Exr3";
            this.Exr3.Size = new System.Drawing.Size(157, 31);
            this.Exr3.TabIndex = 6;
            this.Exr3.Text = "Exercicio 3";
            // 
            // FrmExercicio03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(608, 344);
            this.Controls.Add(this.Exr3);
            this.Controls.Add(this.lblPagar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtPrato);
            this.Controls.Add(this.txtQuilo);
            this.Controls.Add(this.lblPrato);
            this.Controls.Add(this.lblQuilo);
            this.Name = "FrmExercicio03";
            this.Text = "FrmExercicio03";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuilo;
        private System.Windows.Forms.Label lblPrato;
        private System.Windows.Forms.TextBox txtQuilo;
        private System.Windows.Forms.TextBox txtPrato;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblPagar;
        private System.Windows.Forms.Label Exr3;
    }
}